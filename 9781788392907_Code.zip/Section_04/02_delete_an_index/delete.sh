curl -XPOST http://127.0.0.1:9200/myindex/_close
curl -XPOST http://127.0.0.1:9200/myindex/_open
